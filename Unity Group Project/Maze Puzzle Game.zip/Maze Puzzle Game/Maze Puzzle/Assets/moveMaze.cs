﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moveMaze : MonoBehaviour
{
    //Allows changing of the hero.
    public Transform heroObj;

	// Use this for initialization
	void Start ()
    {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        //Move the map down when the W key is pressed
		if (Input.GetKey("w"))
        {
            GetComponent<Rigidbody2D>().velocity = new Vector2(0, -3);
            //Turns the character object around so it faces the direction you are facing. 
            heroObj.transform.eulerAngles = new Vector3(0, 0, -90);
            //heroObj.transform.eulerAngles = new Vector3(0, 0, 0);
        }

        else
        //Move the map up when the S key is pressed
        if (Input.GetKey("s"))
        {
            GetComponent<Rigidbody2D>().velocity = new Vector2(0, 3);
            heroObj.transform.eulerAngles = new Vector3(0, 0, 90);
        }

        else
        //Move the map right when the A key is pressed
        if (Input.GetKey("a"))
        {
            GetComponent<Rigidbody2D>().velocity = new Vector2(3, 0);
            heroObj.transform.eulerAngles = new Vector3(0, 0, 0);
        }

        else
        //Move the map left when the D key is pressed
        if (Input.GetKey("d"))
        {
            GetComponent<Rigidbody2D>().velocity = new Vector2(-3, 0);
            heroObj.transform.eulerAngles = new Vector3(0, 180, 0);
        }

        else
        //Stops the map from moving continously. 
        {
            GetComponent<Rigidbody2D>().velocity = new Vector2(0, 0);
        }
    }
}
